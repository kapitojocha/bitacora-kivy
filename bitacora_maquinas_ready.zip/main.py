# -*- coding: utf-8 -*-
from kivy.app import App
from kivy.lang import Builder
from kivy.core.window import Window

Window.clearcolor = (0.10, 0.12, 0.16, 1)

KV = '''
BoxLayout:
    orientation: 'vertical'
    padding: '16dp'
    spacing: '16dp'
    Label:
        text: "Bitacora de maquinas"
        font_size: '22sp'
    Label:
        text: "APK listo para compilar con GitHub Actions"
        halign: 'center'
        valign: 'middle'
        text_size: self.size
'''

class MainApp(App):
    title = "Bitacora de maquinas"
    def build(self):
        return Builder.load_string(KV)

if __name__ == "__main__":
    MainApp().run()
