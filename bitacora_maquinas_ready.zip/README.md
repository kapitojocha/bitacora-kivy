# Bitacora de maquinas (Kivy)
Proyecto listo para compilar APK con GitHub Actions.

## Cómo usar
1) Sube el contenido de esta carpeta a tu repo (no subas el ZIP como archivo único).
2) En GitHub, ve a **Actions** → **Build APK (Kivy)** → **Run workflow**.
3) Al terminar, descarga el artefacto `bitacora-apk` con el `.apk` listo.

> Reemplaza `main.py` por tu app real cuando quieras. Mantén `buildozer.spec` y `.github/workflows/build.yml`.
