# bitacora-kivy
Bitácora de Mantenciones - Aplicación Kivy para registro de motores y generadores marinos.
